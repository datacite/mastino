# tags
CLUSTER = "cassandra.cluster"
KEYSPACE = "cassandra.keyspace"
CONSISTENCY_LEVEL = "cassandra.consistency_level"
PAGINATED = "cassandra.paginated"
PAGE_NUMBER = "cassandra.page_number"
