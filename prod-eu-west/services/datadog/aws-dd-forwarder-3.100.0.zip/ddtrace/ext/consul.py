APP = "consul"
SERVICE = "consul"
CMD = "consul.command"
KEY = "consul.key"
