"""
Standard network tags.
"""

# request targets
TARGET_HOST = "out.host"
TARGET_PORT = "network.destination.port"

BYTES_OUT = "net.out.bytes"
