COMPONENT_VALUE = "unittest"
FRAMEWORK = "unittest"
KIND = "test"

TEST_OPERATION_NAME = "unittest.test"
SUITE_OPERATION_NAME = "unittest.test_suite"
SESSION_OPERATION_NAME = "unittest.test_session"
MODULE_OPERATION_NAME = "unittest.test_module"
